package com.dao;

public interface IPublisher {
	
	public boolean login(String username, String password) ; 
}
